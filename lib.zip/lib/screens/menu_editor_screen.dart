import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/foundation.dart';
import '../providers/product_provider.dart';
import '../providers/menu_provider.dart';
import '../models/menu.dart';
import '../models/promotion.dart';
import '../services/pdf_service.dart';
import '../widgets/menu_category_editor.dart';
import '../widgets/promotion_editor.dart';

class MenuEditorScreen extends StatefulWidget {
  const MenuEditorScreen({Key? key}) : super(key: key);

  @override
  State<MenuEditorScreen> createState() => _MenuEditorScreenState();
}

class _MenuEditorScreenState extends State<MenuEditorScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isGeneratingPdf = false;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final menuProvider = Provider.of<MenuProvider>(context, listen: false);
      if (menuProvider.currentMenu != null) {
        _titleController.text = menuProvider.currentMenu!.title;
        _descriptionController.text = menuProvider.currentMenu!.description ?? '';
      }
    });
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _generatePdf() async {
    if (!_formKey.currentState!.validate()) return;
    
    _formKey.currentState!.save();
    
    setState(() {
      _isGeneratingPdf = true;
    });
    
    try {
      final menuProvider = Provider.of<MenuProvider>(context, listen: false);
      final pdfService = PdfService();
      
      final pdfBytes = await pdfService.generateMenuPdf(menuProvider.currentMenu!);
      
      final fileName = '${menuProvider.currentMenu!.title.replaceAll(' ', '_')}_${DateTime.now().millisecondsSinceEpoch}.pdf';
      await pdfService.savePdf(pdfBytes, fileName);
      
      await pdfService.sharePdf(pdfBytes, fileName);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al generar PDF: $e')),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isGeneratingPdf = false;
        });
      }
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final menuProvider = Provider.of<MenuProvider>(context);
    final menu = menuProvider.currentMenu;
    
    if (menu == null) {
      return const Center(child: CircularProgressIndicator());
    }
    
    return Scaffold(
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            TabBar(
              controller: _tabController,
              tabs: const [
                Tab(text: 'General'),
                Tab(text: 'Categorías'),
                Tab(text: 'Promociones'),
              ],
            ),
            
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Información General',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _titleController,
                          decoration: const InputDecoration(
                            labelText: 'Título del Menú',
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Por favor ingresa un título';
                            }
                            return null;
                          },
                          onChanged: (value) {
                            menuProvider.updateMenuTitle(value);
                          },
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _descriptionController,
                          decoration: const InputDecoration(
                            labelText: 'Descripción (opcional)',
                            border: OutlineInputBorder(),
                          ),
                          maxLines: 3,
                          onChanged: (value) {
                            menuProvider.updateMenuDescription(value);
                          },
                        ),
                        const SizedBox(height: 24),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.info_outline,
                                    color: Theme.of(context).colorScheme.primary,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    'Diseño del PDF',
                                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).colorScheme.primary,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'El PDF se generará con un diseño elegante y moderno, incluyendo:',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                              const SizedBox(height: 8),
                              const Text('• Portada con título y descripción'),
                              const Text('• Todas las categorías en formato continuo'),
                              const Text('• Promociones al final del documento'),
                              const Text('• Tipografía elegante y diseño profesional'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  menu.categories.isEmpty
                      ? const Center(child: Text('No hay categorías disponibles'))
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: menu.categories.length,
                          itemBuilder: (ctx, index) {
                            return MenuCategoryEditor(
                              category: menu.categories[index],
                              onDescriptionChanged: (description) {
                                menuProvider.updateCategoryDescription(
                                  menu.categories[index].name,
                                  description,
                                );
                              },
                              onProductToggled: (productId) {
                                menuProvider.toggleProductInMenu(
                                  menu.categories[index].name,
                                  productId,
                                );
                              },
                            );
                          },
                        ),
                  
                  SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Promociones',
                              style: Theme.of(context).textTheme.titleLarge,
                            ),
                            ElevatedButton.icon(
                              onPressed: () {
                                final productProvider = Provider.of<ProductProvider>(context, listen: false);
                                final availableProducts = productProvider.products.where((p) => p.isDisponible).toList();
                                
                                showModalBottomSheet(
                                  context: context,
                                  isScrollControlled: true,
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                                  ),
                                  builder: (ctx) => PromotionEditor(
                                    promotion: Promotion.empty(),
                                    availableProducts: availableProducts,
                                    onSave: (promotion) {
                                      menuProvider.addPromotion(promotion);
                                      Navigator.of(ctx).pop();
                                    },
                                  ),
                                );
                              },
                              icon: const Icon(Icons.add),
                              label: const Text('Nueva Promoción'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        menu.promotions.isEmpty
                            ? Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(32),
                                  child: Column(
                                    children: [
                                      Icon(
                                        Icons.local_offer_outlined,
                                        size: 64,
                                        color: Colors.grey.shade400,
                                      ),
                                      const SizedBox(height: 16),
                                      Text(
                                        'No hay promociones',
                                        style: Theme.of(context).textTheme.titleMedium,
                                      ),
                                      const SizedBox(height: 8),
                                      const Text(
                                        'Crea promociones para mostrar ofertas especiales en tu menú',
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: menu.promotions.length,
                                itemBuilder: (ctx, index) {
                                  final promotion = menu.promotions[index];
                                  return Card(
                                    margin: const EdgeInsets.only(bottom: 16),
                                    child: Padding(
                                      padding: const EdgeInsets.all(16),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  promotion.title,
                                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                              Row(
                                                children: [
                                                  IconButton(
                                                    icon: const Icon(Icons.edit),
                                                    onPressed: () {
                                                      final productProvider = Provider.of<ProductProvider>(context, listen: false);
                                                      final availableProducts = productProvider.products.where((p) => p.isDisponible).toList();
                                                      
                                                      showModalBottomSheet(
                                                        context: context,
                                                        isScrollControlled: true,
                                                        shape: const RoundedRectangleBorder(
                                                          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                                                        ),
                                                        builder: (ctx) => PromotionEditor(
                                                          promotion: promotion,
                                                          availableProducts: availableProducts,
                                                          onSave: (updatedPromotion) {
                                                            menuProvider.updatePromotion(index, updatedPromotion);
                                                            Navigator.of(ctx).pop();
                                                          },
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                  IconButton(
                                                    icon: const Icon(Icons.delete, color: Colors.red),
                                                    onPressed: () {
                                                      showDialog(
                                                        context: context,
                                                        builder: (ctx) => AlertDialog(
                                                          title: const Text('Eliminar Promoción'),
                                                          content: const Text('¿Estás seguro que deseas eliminar esta promoción?'),
                                                          actions: [
                                                            TextButton(
                                                              onPressed: () => Navigator.of(ctx).pop(),
                                                              child: const Text('Cancelar'),
                                                            ),
                                                            TextButton(
                                                              onPressed: () {
                                                                menuProvider.removePromotion(index);
                                                                Navigator.of(ctx).pop();
                                                              },
                                                              child: const Text('Eliminar'),
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          if (promotion.description != null && promotion.description!.isNotEmpty)
                                            Padding(
                                              padding: const EdgeInsets.only(top: 8),
                                              child: Text(promotion.description!),
                                            ),
                                          const SizedBox(height: 16),
                                          Text(
                                            'Productos:',
                                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          const SizedBox(height: 8),
                                          ...promotion.items.map((item) => Padding(
                                            padding: const EdgeInsets.only(bottom: 4),
                                            child: Text('• ${item.quantity}x ${item.product.nombre}'),
                                          )).toList(),
                                          const SizedBox(height: 16),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    'Precio original: ${promotion.originalPrice.toStringAsFixed(2)} Bs.',
                                                    style: const TextStyle(
                                                      decoration: TextDecoration.lineThrough,
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                                  Text(
                                                    'Precio promocional: ${promotion.promotionalPrice.toStringAsFixed(2)} Bs.',
                                                    style: TextStyle(
                                                      fontWeight: FontWeight.bold,
                                                      color: Theme.of(context).colorScheme.primary,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Column(
                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                children: [
                                                  Text(
                                                    'Desde: ${_formatDate(promotion.startDate)}',
                                                    style: Theme.of(context).textTheme.bodySmall,
                                                  ),
                                                  Text(
                                                    'Hasta: ${_formatDate(promotion.endDate)}',
                                                    style: Theme.of(context).textTheme.bodySmall,
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isGeneratingPdf ? null : _generatePdf,
        icon: _isGeneratingPdf
            ? const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(color: Colors.white),
              )
            : const Icon(Icons.picture_as_pdf),
        label: const Text('Generar PDF'),
      ),
    );
  }
  
  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }
}
