import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter/foundation.dart';

import '../models/product.dart';
import '../models/empresa.dart';

class ApiService {
  final String baseUrl = dotenv.env['API_URL'] ?? 'http://localhost:3000';
  final String? token;
  
  ApiService({this.token});
  
  Map<String, String> get headers => {
    'Content-Type': 'application/json',
    if (token != null) 'Authorization': 'Bearer $token',
  };
  
  Future<List<Product>> getProducts(int empresaId) async {
    try {
      if (kDebugMode) {
        print('Obteniendo productos para empresa ID: $empresaId');
      }
      
      final response = await http.get(
        Uri.parse('$baseUrl/api/erpproductos'),
        headers: headers,
      ).timeout(const Duration(seconds: 15));
      
      if (response.statusCode == 200) {
        final List<dynamic> productsJson = json.decode(response.body);
        
        if (kDebugMode) {
          print('Total de productos recibidos: ${productsJson.length}');
        }
        
        final List<Product> allProducts = [];
        for (var json in productsJson) {
          try {
            allProducts.add(Product.fromJson(json));
          } catch (e) {
            if (kDebugMode) {
              print('Error al procesar producto: $e');
            }
          }
        }
        
        // Filtrar productos por empresa y disponibilidad
        final filteredProducts = allProducts.where((product) => 
          product.empresaId == empresaId && 
          product.isDisponible && 
          !product.isDescontinuado
        ).toList();
        
        if (kDebugMode) {
          print('Productos filtrados para empresa $empresaId: ${filteredProducts.length}');
        }
        
        return filteredProducts;
      } else if (response.statusCode == 401) {
        throw Exception('Sesión expirada. Inicie sesión nuevamente');
      } else if (response.statusCode == 403) {
        throw Exception('No tiene permisos para acceder a los productos');
      } else if (response.statusCode >= 500) {
        throw Exception('Error del servidor. Intente más tarde');
      } else {
        throw Exception('Error al obtener productos: ${response.statusCode}');
      }
    } catch (e) {
      if (e.toString().contains('TimeoutException')) {
        throw Exception('Tiempo de espera agotado. Verifique su conexión');
      }
      
      if (kDebugMode) {
        print('Excepción al obtener productos: $e');
      }
      
      rethrow;
    }
  }
  
  Future<Empresa> getEmpresa(int empresaId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/erpempresas/$empresaId'),
        headers: headers,
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final empresaJson = json.decode(response.body);
        return Empresa.fromJson(empresaJson);
      } else if (response.statusCode == 401) {
        throw Exception('Sesión expirada');
      } else if (response.statusCode == 404) {
        throw Exception('Empresa no encontrada');
      } else {
        throw Exception('Error al obtener empresa: ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error al obtener empresa: $e');
      }
      rethrow;
    }
  }
}
