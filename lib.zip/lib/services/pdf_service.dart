import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:universal_html/html.dart' as html;
import '../models/menu.dart';
import '../models/promotion.dart';

class PdfService {
  Future<Uint8List> generateMenuPdf(Menu menu) async {
    final pdf = pw.Document();
    
    final regularFont = await PdfGoogleFonts.nunitoRegular();
    final boldFont = await PdfGoogleFonts.nunitoBold();
    final italicFont = await PdfGoogleFonts.nunitoItalic();
    
    pw.MemoryImage? backgroundImage;
    pw.MemoryImage? headerImage;
    pw.MemoryImage? footerImage;
    
    try {
      if (menu.backgroundImage != null && menu.backgroundImage!.isNotEmpty) {
        final bgImageBytes = await _loadImageFromPath(menu.backgroundImage!);
        backgroundImage = pw.MemoryImage(bgImageBytes);
      }
      
      if (menu.headerImage != null && menu.headerImage!.isNotEmpty) {
        final headerImageBytes = await _loadImageFromPath(menu.headerImage!);
        headerImage = pw.MemoryImage(headerImageBytes);
      }
      
      if (menu.footerImage != null && menu.footerImage!.isNotEmpty) {
        final footerImageBytes = await _loadImageFromPath(menu.footerImage!);
        footerImage = pw.MemoryImage(footerImageBytes);
      }
    } catch (e) {
      print('Error loading images: $e');
    }
    
    final theme = pw.ThemeData.withFont(
      base: regularFont,
      bold: boldFont,
      italic: italicFont,
    );
    
    final titleStyle = pw.TextStyle(
      fontSize: 28,
      fontWeight: pw.FontWeight.bold,
      color: PdfColor.fromInt(0xFF1565C0),
    );
    
    final subtitleStyle = pw.TextStyle(
      fontSize: 14,
      color: PdfColor.fromInt(0xFF757575),
    );
    
    final categoryTitleStyle = pw.TextStyle(
      fontSize: 18,
      fontWeight: pw.FontWeight.bold,
      color: PdfColor.fromInt(0xFF1976D2),
    );
    
    final productNameStyle = pw.TextStyle(
      fontSize: 12,
      fontWeight: pw.FontWeight.bold,
      color: PdfColor.fromInt(0xFF424242),
    );
    
    final productDescStyle = pw.TextStyle(
      fontSize: 10,
      color: PdfColor.fromInt(0xFF757575),
    );
    
    final priceStyle = pw.TextStyle(
      fontSize: 12,
      fontWeight: pw.FontWeight.bold,
      color: PdfColor.fromInt(0xFF1976D2),
    );

    Future<pw.Widget> buildCategoryImage(String? imagePath) async {
      if (imagePath == null || imagePath.isEmpty) {
        return pw.SizedBox.shrink();
      }
      
      try {
        final imageBytes = await _loadImageFromPath(imagePath);
        return pw.ClipRRect(
          horizontalRadius: 25,
          verticalRadius: 25,
          child: pw.Image(
            pw.MemoryImage(imageBytes),
            fit: pw.BoxFit.cover,
          ),
        );
      } catch (e) {
        print('Error loading category image: $e');
        return pw.SizedBox.shrink();
      }
    }
    
    // Portada
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        theme: theme,
        build: (pw.Context context) {
          return pw.Stack(
            children: [
              pw.Positioned.fill(
                child: pw.Container(
                  decoration: pw.BoxDecoration(
                    gradient: pw.LinearGradient(
                      colors: [
                        PdfColor.fromInt(0xFFE3F2FD),
                        PdfColors.white,
                      ],
                      begin: pw.Alignment.topCenter,
                      end: pw.Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
              
              if (backgroundImage != null)
                pw.Positioned.fill(
                  child: pw.Opacity(
                    opacity: 0.15,
                    child: pw.Image(backgroundImage, fit: pw.BoxFit.cover),
                  ),
                ),
              
              pw.Center(
                child: pw.Column(
                  mainAxisAlignment: pw.MainAxisAlignment.center,
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  children: [
                    if (headerImage != null)
                      pw.Container(
                        margin: const pw.EdgeInsets.only(bottom: 30),
                        child: pw.Image(headerImage, width: 180),
                      ),
                    
                    pw.Container(
                      margin: const pw.EdgeInsets.only(bottom: 10),
                      child: pw.Text(
                        menu.title.toUpperCase(),
                        style: titleStyle,
                        textAlign: pw.TextAlign.center,
                      ),
                    ),
                    
                    if (menu.description != null && menu.description!.isNotEmpty)
                      pw.Container(
                        width: 400,
                        margin: const pw.EdgeInsets.only(bottom: 30),
                        child: pw.Text(
                          menu.description!,
                          style: subtitleStyle,
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                    
                    pw.Container(
                      margin: const pw.EdgeInsets.only(top: 20),
                      padding: const pw.EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      decoration: pw.BoxDecoration(
                        color: PdfColor.fromInt(0xFF1976D2),
                        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(20)),
                      ),
                      child: pw.Text(
                        _formatDate(menu.createdAt),
                        style: pw.TextStyle(
                          fontSize: 12,
                          color: PdfColors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              if (footerImage != null)
                pw.Positioned(
                  bottom: 30,
                  left: 0,
                  right: 0,
                  child: pw.Center(
                    child: pw.Image(footerImage, width: 120),
                  ),
                ),
            ],
          );
        },
      ),
    );
    
    // Categorías
    for (final category in menu.categories) {
      if (category.products.isNotEmpty) {
        final categoryImageWidget = await buildCategoryImage(category.image);
        const productsPerPage = 15;
        final pageCount = (category.products.length / productsPerPage).ceil();
        
        for (var pageIndex = 0; pageIndex < pageCount; pageIndex++) {
          final startIndex = pageIndex * productsPerPage;
          final endIndex = (pageIndex + 1) * productsPerPage < category.products.length 
              ? (pageIndex + 1) * productsPerPage 
              : category.products.length;
          final products = category.products.sublist(startIndex, endIndex);
          
          pdf.addPage(
            pw.Page(
              pageFormat: PdfPageFormat.a4,
              theme: theme,
              build: (pw.Context context) {
                return pw.Stack(
                  children: [
                    pw.Positioned.fill(
                      child: pw.Container(
                        decoration: pw.BoxDecoration(
                          gradient: pw.LinearGradient(
                            colors: [
                              PdfColor.fromInt(0xFFE3F2FD),
                              PdfColors.white,
                            ],
                            begin: pw.Alignment.topLeft,
                            end: pw.Alignment.bottomRight,
                          ),
                        ),
                      ),
                    ),
                    
                    if (backgroundImage != null)
                      pw.Positioned.fill(
                        child: pw.Opacity(
                          opacity: 0.05,
                          child: pw.Image(backgroundImage, fit: pw.BoxFit.cover),
                        ),
                      ),
                    
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(30),
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          if (pageIndex == 0) ...[
                            pw.Row(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              children: [
                                if (categoryImageWidget != null)
                                  pw.Container(
                                    width: 50,
                                    height: 50,
                                    margin: const pw.EdgeInsets.only(right: 15),
                                    child: categoryImageWidget,
                                  ),
                                
                                pw.Expanded(
                                  child: pw.Column(
                                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                                    children: [
                                      pw.Text(
                                        category.name.toUpperCase(),
                                        style: categoryTitleStyle,
                                      ),
                                      if (category.description != null && category.description!.isNotEmpty)
                                        pw.Text(
                                          category.description!,
                                          style: productDescStyle,
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            
                            pw.SizedBox(height: 15),
                            pw.Container(
                              height: 1,
                              margin: const pw.EdgeInsets.symmetric(vertical: 10),
                              decoration: pw.BoxDecoration(
                                gradient: pw.LinearGradient(
                                  colors: [
                                    PdfColors.white,
                                    PdfColor.fromInt(0xFF64B5F6),
                                    PdfColors.white,
                                  ],
                                ),
                              ),
                            ),
                            pw.SizedBox(height: 10),
                          ],
                          
                          pw.Table(
                            border: pw.TableBorder(
                              horizontalInside: pw.BorderSide(
                                color: PdfColor.fromInt(0xFFEEEEEE),
                                width: 0.5,
                              ),
                            ),
                            children: [
                              if (pageIndex == 0)
                                pw.TableRow(
                                  decoration: pw.BoxDecoration(
                                    color: PdfColor.fromInt(0xFFE3F2FD),
                                  ),
                                  children: [
                                    pw.Padding(
                                      padding: const pw.EdgeInsets.symmetric(vertical: 8),
                                      child: pw.Text(
                                        'Producto',
                                        style: productNameStyle.copyWith(
                                          color: PdfColor.fromInt(0xFF1976D2)),
                                      ),
                                    ),
                                    pw.Padding(
                                      padding: const pw.EdgeInsets.symmetric(vertical: 8),
                                      child: pw.Text(
                                        'Precio',
                                        style: productNameStyle.copyWith(
                                          color: PdfColor.fromInt(0xFF1976D2)),
                                        textAlign: pw.TextAlign.right,
                                      ),
                                    ),
                                  ],
                                ),
                              
                              for (final product in products)
                                pw.TableRow(
                                  children: [
                                    pw.Padding(
                                      padding: const pw.EdgeInsets.symmetric(vertical: 8),
                                      child: pw.Column(
                                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                                        children: [
                                          pw.Text(
                                            product.nombre,
                                            style: productNameStyle,
                                          ),
                                          if (product.descripcion.isNotEmpty)
                                            pw.Text(
                                              product.descripcion,
                                              style: productDescStyle,
                                            ),
                                        ],
                                      ),
                                    ),
                                    pw.Padding(
                                      padding: const pw.EdgeInsets.symmetric(vertical: 8),
                                      child: pw.Text(
                                        '${product.precio.toStringAsFixed(2)} Bs.',
                                        style: priceStyle,
                                        textAlign: pw.TextAlign.right,
                                      ),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                          
                          if (pageIndex < pageCount - 1)
                            pw.Container(
                              margin: const pw.EdgeInsets.only(top: 20),
                              child: pw.Text(
                                '(Continúa en la siguiente página...)',
                                style: const pw.TextStyle(
                                  fontSize: 10,
                                  color: PdfColor.fromInt(0xFF757575),
                                ),
                                textAlign: pw.TextAlign.center,
                              ),
                            ),
                        ],
                      ),
                    ),
                    
                    pw.Positioned(
                      top: 20,
                      left: 0,
                      right: 0,
                      child: pw.Padding(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 30),
                        child: pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                          children: [
                            pw.Text(
                              menu.title,
                              style: const pw.TextStyle(
                                fontSize: 10,
                                color: PdfColor.fromInt(0xFF757575),
                              ),
                            ),
                            pw.Text(
                              category.name,
                              style: const pw.TextStyle(
                                fontSize: 10,
                                color: PdfColor.fromInt(0xFF757575),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    pw.Positioned(
                      bottom: 20,
                      left: 0,
                      right: 0,
                      child: pw.Padding(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 30),
                        child: pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                          children: [
                            if (footerImage != null)
                              pw.Image(footerImage, width: 80),
                            pw.Text(
                              'Página ${context.pageNumber} de ${context.pagesCount}',
                              style: const pw.TextStyle(
                                fontSize: 10,
                                color: PdfColor.fromInt(0xFF757575),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          );
        }
      }
    }
    
    // Promociones
    if (menu.promotions.isNotEmpty) {
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          theme: theme,
          build: (pw.Context context) {
            return pw.Stack(
              children: [
                pw.Positioned.fill(
                  child: pw.Container(
                    decoration: pw.BoxDecoration(
                      gradient: pw.LinearGradient(
                        colors: [
                          PdfColor.fromInt(0xFFE3F2FD),
                          PdfColors.white,
                        ],
                        begin: pw.Alignment.topLeft,
                        end: pw.Alignment.bottomRight,
                      ),
                    ),
                  ),
                ),
                
                pw.Padding(
                  padding: const pw.EdgeInsets.all(30),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Center(
                        child: pw.Container(
                          margin: const pw.EdgeInsets.only(bottom: 20),
                          child: pw.Text(
                            'PROMOCIONES ESPECIALES',
                            style: pw.TextStyle(
                              fontSize: 22,
                              fontWeight: pw.FontWeight.bold,
                              color: PdfColor.fromInt(0xFF1565C0),
                            ),
                          ),
                        ),
                      ),
                      
                      for (final promotion in menu.promotions)
                        pw.Container(
                          width: double.infinity,
                          margin: const pw.EdgeInsets.only(bottom: 20),
                          decoration: pw.BoxDecoration(
                            color: PdfColors.white,
                            borderRadius: const pw.BorderRadius.all(pw.Radius.circular(8)),
                            boxShadow: [
                              pw.BoxShadow(
                                color: PdfColor.fromInt(0xFFE0E0E0),
                                blurRadius: 5,
                              ),
                            ],
                          ),
                          child: pw.Padding(
                            padding: const pw.EdgeInsets.all(15),
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text(
                                  promotion.title,
                                  style: pw.TextStyle(
                                    fontSize: 18,
                                    fontWeight: pw.FontWeight.bold,
                                    color: PdfColor.fromInt(0xFF1976D2),
                                  ),
                                ),
                                
                                pw.SizedBox(height: 5),
                                
                                if (promotion.description != null && promotion.description!.isNotEmpty)
                                  pw.Text(
                                    promotion.description!,
                                    style: const pw.TextStyle(
                                      fontSize: 12,
                                      color: PdfColor.fromInt(0xFF757575),
                                    ),
                                  ),
                                
                                pw.SizedBox(height: 10),
                                
                                pw.Text(
                                  'Incluye:',
                                  style: pw.TextStyle(
                                    fontSize: 12,
                                    fontWeight: pw.FontWeight.bold,
                                    color: PdfColor.fromInt(0xFF616161),
                                  ),
                                ),
                                
                                pw.SizedBox(height: 5),
                                
                                for (final item in promotion.items)
                                  pw.Padding(
                                    padding: const pw.EdgeInsets.only(left: 10, bottom: 3),
                                    child: pw.Text(
                                      '• ${item.quantity}x ${item.product.nombre}',
                                      style: const pw.TextStyle(fontSize: 11),
                                    ),
                                  ),
                                
                                pw.SizedBox(height: 15),
                                
                                pw.Row(
                                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                                  children: [
                                    pw.Column(
                                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                                      children: [
                                        pw.Text(
                                          'Precio normal: ${promotion.originalPrice.toStringAsFixed(2)} Bs.',
                                          style: const pw.TextStyle(
                                            fontSize: 11,
                                            decoration: pw.TextDecoration.lineThrough,
                                            color: PdfColor.fromInt(0xFF757575),
                                          ),
                                        ),
                                        pw.Text(
                                          'Precio promoción: ${promotion.promotionalPrice.toStringAsFixed(2)} Bs.',
                                          style: pw.TextStyle(
                                            fontSize: 14,
                                            fontWeight: pw.FontWeight.bold,
                                            color: PdfColor.fromInt(0xFF388E3C),
                                          ),
                                        ),
                                      ],
                                    ),
                                    
                                    pw.Column(
                                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                                      children: [
                                        pw.Text(
                                          'Válido desde: ${_formatDate(promotion.startDate)}',
                                          style: const pw.TextStyle(fontSize: 10),
                                        ),
                                        pw.Text(
                                          'Válido hasta: ${_formatDate(promotion.endDate)}',
                                          style: const pw.TextStyle(fontSize: 10),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                
                pw.Positioned(
                  top: 20,
                  left: 0,
                  right: 0,
                  child: pw.Padding(
                    padding: const pw.EdgeInsets.symmetric(horizontal: 30),
                    child: pw.Text(
                      'Promociones - ${menu.title}',
                      style: const pw.TextStyle(
                        fontSize: 10,
                        color: PdfColor.fromInt(0xFF757575),
                      ),
                    ),
                  ),
                ),
                
                pw.Positioned(
                  bottom: 20,
                  left: 0,
                  right: 0,
                  child: pw.Padding(
                    padding: const pw.EdgeInsets.symmetric(horizontal: 30),
                    child: pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [
                        if (footerImage != null)
                          pw.Image(footerImage, width: 80),
                        pw.Text(
                          'Página ${context.pageNumber} de ${context.pagesCount}',
                          style: const pw.TextStyle(
                            fontSize: 10,
                            color: PdfColor.fromInt(0xFF757575),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      );
    }
    
    return pdf.save();
  }
  
  Future<Uint8List> _loadImageFromPath(String path) async {
    try {
      if (path.startsWith('http')) {
        final response = await http.get(Uri.parse(path));
        if (response.statusCode == 200) {
          return response.bodyBytes;
        } else {
          throw Exception('Failed to load image from URL: ${response.statusCode}');
        }
      } else if (path.startsWith('assets/')) {
        final byteData = await rootBundle.load(path);
        return byteData.buffer.asUint8List();
      } else {
        if (path == 'assets/images/background.jpg' || 
            path == 'assets/images/header.webp' || 
            path == 'assets/images/footer.jpg') {
          final byteData = await rootBundle.load(path);
          return byteData.buffer.asUint8List();
        }
        throw Exception('Solo se permiten imágenes de assets');
      }
    } catch (e) {
      print('Error loading image from path $path: $e');
      final byteData = await rootBundle.load('assets/images/header.webp');
      return byteData.buffer.asUint8List();
    }
  }
  
  String _formatDate(DateTime date) {
    final months = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];
    
    return '${date.day} de ${months[date.month - 1]} de ${date.year}';
  }
  
  Future<void> savePdf(Uint8List pdfBytes, String fileName) async {
    try {
      if (kIsWeb) {
        final blob = html.Blob([pdfBytes], 'application/pdf');
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.AnchorElement(href: url)
          ..setAttribute('download', fileName)
          ..click();
        html.Url.revokeObjectUrl(url);
      } else {
        final directory = await getApplicationDocumentsDirectory();
        final file = File('${directory.path}/$fileName');
        await file.writeAsBytes(pdfBytes);
        print('PDF guardado en: ${file.path}');
      }
    } catch (e) {
      print('Error al guardar PDF: $e');
      throw Exception('Error al guardar PDF: $e');
    }
  }
  
  Future<void> sharePdf(Uint8List pdfBytes, String fileName) async {
    try {
      await Printing.sharePdf(bytes: pdfBytes, filename: fileName);
    } catch (e) {
      print('Error al compartir PDF: $e');
      throw Exception('Error al compartir PDF: $e');
    }
  }
  
  Future<void> printPdf(Uint8List pdfBytes) async {
    try {
      await Printing.layoutPdf(onLayout: (_) => pdfBytes);
    } catch (e) {
      print('Error al imprimir PDF: $e');
      throw Exception('Error al imprimir PDF: $e');
    }
  }
}