import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:universal_html/html.dart' as html;
import '../models/menu.dart';
import '../models/promotion.dart';

class PdfService {
  Future<Uint8List> generateMenuPdf(Menu menu) async {
    final pdf = pw.Document();
    
    // Cargar fuentes elegantes
    final regularFont = await PdfGoogleFonts.playfairDisplayRegular();
    final boldFont = await PdfGoogleFonts.playfairDisplayBold();
    final bodyFont = await PdfGoogleFonts.crimsonTextRegular();
    final bodyBoldFont = await PdfGoogleFonts.crimsonTextSemiBold();
    
    // Cargar imágenes de assets
    pw.MemoryImage? backgroundImage;
    pw.MemoryImage? coverImage;
    
    try {
      final bgImageBytes = await rootBundle.load('assets/images/background.jpg');
      backgroundImage = pw.MemoryImage(bgImageBytes.buffer.asUint8List());
      
      final coverImageBytes = await rootBundle.load('assets/images/header.webp');
      coverImage = pw.MemoryImage(coverImageBytes.buffer.asUint8List());
    } catch (e) {
      print('Error loading images: $e');
    }
    
    final theme = pw.ThemeData.withFont(
      base: regularFont,
      bold: boldFont,
    );
    
    // Colores elegantes y sofisticados
    const primaryColor = PdfColor.fromInt(0xFF1A1A1A);      // Negro elegante
    const accentColor = PdfColor.fromInt(0xFFD4AF37);       // Dorado elegante
    const lightAccent = PdfColor.fromInt(0xFFF5F5DC);       // Beige claro
    const darkGray = PdfColor.fromInt(0xFF4A4A4A);          // Gris oscuro
    const lightGray = PdfColor.fromInt(0xFFF8F8F8);         // Gris muy claro
    
    // Estilos de texto elegantes
    final titleStyle = pw.TextStyle(
      font: boldFont,
      fontSize: 42,
      color: primaryColor,
      letterSpacing: 3,
    );
    
    final subtitleStyle = pw.TextStyle(
      font: regularFont,
      fontSize: 18,
      color: darkGray,
      fontStyle: pw.FontStyle.italic,
      letterSpacing: 1,
    );
    
    final categoryTitleStyle = pw.TextStyle(
      font: boldFont,
      fontSize: 20,
      color: primaryColor,
      letterSpacing: 2,
    );
    
    final productNameStyle = pw.TextStyle(
      font: bodyBoldFont,
      fontSize: 13,
      color: primaryColor,
    );
    
    final productDescStyle = pw.TextStyle(
      font: bodyFont,
      fontSize: 10,
      color: darkGray,
      lineSpacing: 1.3,
    );
    
    final priceStyle = pw.TextStyle(
      font: bodyBoldFont,
      fontSize: 13,
      color: accentColor,
    );

    // PORTADA ULTRA ELEGANTE
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        theme: theme,
        build: (pw.Context context) {
          return pw.Stack(
            children: [
              // Imagen de fondo para la portada
              if (coverImage != null)
                pw.Positioned.fill(
                  child: pw.Opacity(
                    opacity: 0.05,
                    child: pw.Image(coverImage, fit: pw.BoxFit.cover),
                  ),
                ),
              
              // Fondo elegante con gradiente sutil
              pw.Positioned.fill(
                child: pw.Container(
                  decoration: pw.BoxDecoration(
                    gradient: pw.LinearGradient(
                      colors: [
                        PdfColors.white,
                        lightGray,
                        PdfColors.white,
                      ],
                      begin: pw.Alignment.topCenter,
                      end: pw.Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
              
              // Contenido de la portada
              pw.Center(
                child: pw.Column(
                  mainAxisAlignment: pw.MainAxisAlignment.center,
                  children: [
                    // Línea decorativa superior
                    pw.Container(
                      width: 120,
                      height: 2,
                      color: accentColor,
                    ),
                    
                    pw.SizedBox(height: 30),
                    
                    // Título principal ultra elegante
                    pw.Text(
                      menu.title.toUpperCase(),
                      style: titleStyle,
                      textAlign: pw.TextAlign.center,
                    ),
                    
                    pw.SizedBox(height: 25),
                    
                    // Descripción elegante
                    if (menu.description != null && menu.description!.isNotEmpty)
                      pw.Container(
                        width: 450,
                        child: pw.Text(
                          menu.description!,
                          style: subtitleStyle,
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                    
                    pw.SizedBox(height: 30),
                    
                    // Línea decorativa inferior
                    pw.Container(
                      width: 120,
                      height: 2,
                      color: accentColor,
                    ),
                    
                    pw.SizedBox(height: 80),
                    
                    // Fecha en estilo elegante
                    pw.Container(
                      padding: const pw.EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                      decoration: pw.BoxDecoration(
                        border: pw.Border.all(color: accentColor, width: 1),
                      ),
                      child: pw.Text(
                        _formatDate(menu.createdAt),
                        style: pw.TextStyle(
                          font: bodyFont,
                          fontSize: 12,
                          color: primaryColor,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
    
    // Preparar contenido para páginas
    final availableHeight = PdfPageFormat.a4.availableHeight - 120;
    
    List<List<pw.Widget>> pages = [[]];
    int currentPage = 0;
    double currentHeight = 0;
    String? currentCategory;
    
    void addToPage(pw.Widget widget, double height, {bool isCategoryTitle = false, String? categoryName}) {
      if (currentHeight + height > availableHeight) {
        pages.add([]);
        currentPage++;
        currentHeight = 0;
        
        if (currentCategory != null && !isCategoryTitle) {
          final categoryTitleWidget = _buildElegantCategoryTitle(
            currentCategory!, 
            null, 
            categoryTitleStyle, 
            primaryColor, 
            accentColor
          );
          pages[currentPage].add(categoryTitleWidget);
          currentHeight += 60;
        }
      }
      
      pages[currentPage].add(widget);
      currentHeight += height;
      
      if (isCategoryTitle) {
        currentCategory = categoryName;
      }
    }
    
    // Procesar categorías y productos
    for (final category in menu.categories) {
      if (category.products.where((p) => p.isSelected).isNotEmpty) {
        // Título de categoría elegante
        final categoryTitleWidget = _buildElegantCategoryTitle(
          category.name, 
          category.description, 
          categoryTitleStyle, 
          primaryColor, 
          accentColor
        );
        addToPage(categoryTitleWidget, 60, isCategoryTitle: true, categoryName: category.name);
        
        // Productos de la categoría con diseño minimalista
        for (final product in category.products.where((p) => p.isSelected)) {
          final productWidget = _buildMinimalistProductItem(
            product.nombre, 
            product.descripcion, 
            product.precio, 
            productNameStyle, 
            productDescStyle, 
            priceStyle, 
            primaryColor, 
            accentColor
          );
          addToPage(productWidget, 35);
        }
        
        // Espaciado entre categorías
        addToPage(pw.SizedBox(height: 20), 20);
      }
    }
    
    // Crear páginas de contenido
    for (int i = 0; i < pages.length; i++) {
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          theme: theme,
          build: (pw.Context context) {
            return pw.Stack(
              children: [
                // Fondo muy sutil
                if (backgroundImage != null)
                  pw.Positioned.fill(
                    child: pw.Opacity(
                      opacity: 0.015,
                      child: pw.Image(backgroundImage, fit: pw.BoxFit.cover),
                    ),
                  ),
                
                // Contenido principal
                pw.Padding(
                  padding: const pw.EdgeInsets.all(50),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Expanded(
                        child: pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: pages[i],
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Header minimalista
                pw.Positioned(
                  top: 20,
                  left: 50,
                  right: 50,
                  child: pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Text(
                        menu.title,
                        style: pw.TextStyle(
                          font: bodyFont,
                          fontSize: 9,
                          color: darkGray,
                          letterSpacing: 1,
                        ),
                      ),
                      pw.Container(
                        width: 20,
                        height: 1,
                        color: accentColor,
                      ),
                    ],
                  ),
                ),
                
                // Footer minimalista
                pw.Positioned(
                  bottom: 20,
                  left: 50,
                  right: 50,
                  child: pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Container(
                        width: 20,
                        height: 1,
                        color: accentColor,
                      ),
                      pw.Text(
                        '${context.pageNumber - 1}',
                        style: pw.TextStyle(
                          font: bodyFont,
                          fontSize: 9,
                          color: darkGray,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      );
    }
    
    // PÁGINA DE PROMOCIONES ELEGANTE
    if (menu.promotions.isNotEmpty) {
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          theme: theme,
          build: (pw.Context context) {
            return pw.Stack(
              children: [
                // Fondo muy sutil
                if (backgroundImage != null)
                  pw.Positioned.fill(
                    child: pw.Opacity(
                      opacity: 0.015,
                      child: pw.Image(backgroundImage, fit: pw.BoxFit.cover),
                    ),
                  ),
                
                pw.Padding(
                  padding: const pw.EdgeInsets.all(50),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      // Título de promociones elegante
                      pw.Center(
                        child: pw.Column(
                          children: [
                            pw.Container(
                              width: 80,
                              height: 2,
                              color: accentColor,
                            ),
                            pw.SizedBox(height: 25),
                            pw.Text(
                              'OFERTAS ESPECIALES',
                              style: pw.TextStyle(
                                font: boldFont,
                                fontSize: 24,
                                color: primaryColor,
                                letterSpacing: 3,
                              ),
                            ),
                            pw.SizedBox(height: 25),
                            pw.Container(
                              width: 80,
                              height: 2,
                              color: accentColor,
                            ),
                          ],
                        ),
                      ),
                      
                      pw.SizedBox(height: 50),
                      
                      // Lista de promociones elegantes
                      for (final promotion in menu.promotions)
                        pw.Container(
                          width: double.infinity,
                          margin: const pw.EdgeInsets.only(bottom: 40),
                          child: pw.Column(
                            crossAxisAlignment: pw.CrossAxisAlignment.start,
                            children: [
                              // Título de la promoción
                              pw.Row(
                                crossAxisAlignment: pw.CrossAxisAlignment.center,
                                children: [
                                  pw.Container(
                                    width: 4,
                                    height: 25,
                                    color: accentColor,
                                  ),
                                  pw.SizedBox(width: 15),
                                  pw.Expanded(
                                    child: pw.Text(
                                      promotion.title.toUpperCase(),
                                      style: pw.TextStyle(
                                        font: boldFont,
                                        fontSize: 16,
                                        color: primaryColor,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              
                              pw.SizedBox(height: 15),
                              
                              // Descripción
                              if (promotion.description != null && promotion.description!.isNotEmpty) ...[
                                pw.Padding(
                                  padding: const pw.EdgeInsets.only(left: 19),
                                  child: pw.Text(
                                    promotion.description!,
                                    style: pw.TextStyle(
                                      font: bodyFont,
                                      fontSize: 11,
                                      color: darkGray,
                                      fontStyle: pw.FontStyle.italic,
                                    ),
                                  ),
                                ),
                                pw.SizedBox(height: 15),
                              ],
                              
                              // Productos incluidos en estilo minimalista
                              pw.Padding(
                                padding: const pw.EdgeInsets.only(left: 19),
                                child: pw.Column(
                                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                                  children: [
                                    for (final item in promotion.items)
                                      pw.Padding(
                                        padding: const pw.EdgeInsets.only(bottom: 8),
                                        child: pw.Row(
                                          children: [
                                            pw.Text(
                                              '${item.quantity}',
                                              style: pw.TextStyle(
                                                font: bodyBoldFont,
                                                fontSize: 11,
                                                color: accentColor,
                                              ),
                                            ),
                                            pw.SizedBox(width: 8),
                                            pw.Text(
                                              '×',
                                              style: pw.TextStyle(
                                                font: bodyFont,
                                                fontSize: 11,
                                                color: darkGray,
                                              ),
                                            ),
                                            pw.SizedBox(width: 8),
                                            pw.Expanded(
                                              child: pw.Text(
                                                item.product.nombre,
                                                style: pw.TextStyle(
                                                  font: bodyFont,
                                                  fontSize: 11,
                                                  color: primaryColor,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              
                              pw.SizedBox(height: 20),
                              
                              // Precios y fechas en diseño elegante
                              pw.Padding(
                                padding: const pw.EdgeInsets.only(left: 19),
                                child: pw.Row(
                                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                                  children: [
                                    pw.Column(
                                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                                      children: [
                                        pw.Text(
                                          'Precio regular',
                                          style: pw.TextStyle(
                                            font: bodyFont,
                                            fontSize: 9,
                                            color: darkGray,
                                          ),
                                        ),
                                        pw.Text(
                                          '${promotion.originalPrice.toStringAsFixed(2)} Bs.',
                                          style: pw.TextStyle(
                                            font: bodyFont,
                                            fontSize: 11,
                                            decoration: pw.TextDecoration.lineThrough,
                                            color: darkGray,
                                          ),
                                        ),
                                        pw.SizedBox(height: 8),
                                        pw.Text(
                                          'Precio especial',
                                          style: pw.TextStyle(
                                            font: bodyFont,
                                            fontSize: 9,
                                            color: accentColor,
                                          ),
                                        ),
                                        pw.Text(
                                          '${promotion.promotionalPrice.toStringAsFixed(2)} Bs.',
                                          style: pw.TextStyle(
                                            font: bodyBoldFont,
                                            fontSize: 14,
                                            color: accentColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                    
                                    pw.Column(
                                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                                      children: [
                                        pw.Text(
                                          'Válido desde',
                                          style: pw.TextStyle(
                                            font: bodyFont,
                                            fontSize: 9,
                                            color: darkGray,
                                          ),
                                        ),
                                        pw.Text(
                                          _formatDate(promotion.startDate),
                                          style: pw.TextStyle(
                                            font: bodyBoldFont,
                                            fontSize: 10,
                                            color: primaryColor,
                                          ),
                                        ),
                                        pw.SizedBox(height: 8),
                                        pw.Text(
                                          'Válido hasta',
                                          style: pw.TextStyle(
                                            font: bodyFont,
                                            fontSize: 9,
                                            color: darkGray,
                                          ),
                                        ),
                                        pw.Text(
                                          _formatDate(promotion.endDate),
                                          style: pw.TextStyle(
                                            font: bodyBoldFont,
                                            fontSize: 10,
                                            color: primaryColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              
                              // Línea separadora elegante
                              pw.Container(
                                margin: const pw.EdgeInsets.only(top: 25),
                                height: 1,
                                decoration: pw.BoxDecoration(
                                  gradient: pw.LinearGradient(
                                    colors: [
                                      PdfColors.white,
                                      accentColor,
                                      PdfColors.white,
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
                
                // Header
                pw.Positioned(
                  top: 20,
                  left: 50,
                  right: 50,
                  child: pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Text(
                        'Ofertas - ${menu.title}',
                        style: pw.TextStyle(
                          font: bodyFont,
                          fontSize: 9,
                          color: darkGray,
                          letterSpacing: 1,
                        ),
                      ),
                      pw.Container(
                        width: 20,
                        height: 1,
                        color: accentColor,
                      ),
                    ],
                  ),
                ),
                
                // Footer
                pw.Positioned(
                  bottom: 20,
                  left: 50,
                  right: 50,
                  child: pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Container(
                        width: 20,
                        height: 1,
                        color: accentColor,
                      ),
                      pw.Text(
                        '${context.pageNumber - 1}',
                        style: pw.TextStyle(
                          font: bodyFont,
                          fontSize: 9,
                          color: darkGray,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      );
    }
    
    return pdf.save();
  }
  
  // Método para construir el título de una categoría elegante
  pw.Widget _buildElegantCategoryTitle(
    String name, 
    String? description, 
    pw.TextStyle titleStyle, 
    PdfColor primaryColor, 
    PdfColor accentColor
  ) {
    return pw.Container(
      width: double.infinity,
      margin: const pw.EdgeInsets.only(top: 25, bottom: 20),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              pw.Container(
                width: 3,
                height: 20,
                color: accentColor,
              ),
              pw.SizedBox(width: 12),
              pw.Expanded(
                child: pw.Text(
                  name.toUpperCase(),
                  style: titleStyle,
                ),
              ),
            ],
          ),
          if (description != null && description.isNotEmpty) ...[
            pw.SizedBox(height: 8),
            pw.Padding(
              padding: const pw.EdgeInsets.only(left: 15),
              child: pw.Text(
                description,
                style: pw.TextStyle(
                  fontSize: 10,
                  color: const PdfColor.fromInt(0xFF6A6A6A),
                  fontStyle: pw.FontStyle.italic,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
  
  // Método para construir un elemento de producto minimalista
  pw.Widget _buildMinimalistProductItem(
    String name, 
    String description, 
    double price, 
    pw.TextStyle nameStyle, 
    pw.TextStyle descStyle, 
    pw.TextStyle priceStyle, 
    PdfColor primaryColor, 
    PdfColor accentColor
  ) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 12),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          // Contenido del producto
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  name,
                  style: nameStyle,
                ),
                if (description.isNotEmpty) ...[
                  pw.SizedBox(height: 3),
                  pw.Text(
                    description,
                    style: descStyle,
                  ),
                ],
              ],
            ),
          ),
          
          // Puntos de separación elegantes
          pw.Expanded(
            child: pw.Container(
              margin: const pw.EdgeInsets.only(top: 8),
              child: pw.Row(
                children: List.generate(
                  30,
                  (index) => pw.Container(
                    width: 2,
                    height: 1,
                    margin: const pw.EdgeInsets.symmetric(horizontal: 2),
                    color: const PdfColor.fromInt(0xFFE0E0E0),
                  ),
                ),
              ),
            ),
          ),
          
          // Precio
          pw.Text(
            '${price.toStringAsFixed(2)} Bs.',
            style: priceStyle,
          ),
        ],
      ),
    );
  }
  
  String _formatDate(DateTime date) {
    final months = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];
    
    return '${date.day} de ${months[date.month - 1]} de ${date.year}';
  }
  
  Future<void> savePdf(Uint8List pdfBytes, String fileName) async {
    try {
      if (kIsWeb) {
        final blob = html.Blob([pdfBytes], 'application/pdf');
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.AnchorElement(href: url)
          ..setAttribute('download', fileName)
          ..click();
        html.Url.revokeObjectUrl(url);
      } else {
        final directory = await getApplicationDocumentsDirectory();
        final file = File('${directory.path}/$fileName');
        await file.writeAsBytes(pdfBytes);
        print('PDF guardado en: ${file.path}');
      }
    } catch (e) {
      print('Error al guardar PDF: $e');
      throw Exception('Error al guardar PDF: $e');
    }
  }
  
  Future<void> sharePdf(Uint8List pdfBytes, String fileName) async {
    try {
      await Printing.sharePdf(bytes: pdfBytes, filename: fileName);
    } catch (e) {
      print('Error al compartir PDF: $e');
      throw Exception('Error al compartir PDF: $e');
    }
  }
  
  Future<void> printPdf(Uint8List pdfBytes) async {
    try {
      await Printing.layoutPdf(onLayout: (_) => pdfBytes);
    } catch (e) {
      print('Error al imprimir PDF: $e');
      throw Exception('Error al imprimir PDF: $e');
    }
  }
}
