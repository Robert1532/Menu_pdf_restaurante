import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter/foundation.dart';

import '../models/user.dart';
import '../models/empresa.dart';

class AuthService {
  final String baseUrl = dotenv.env['API_URL'] ?? 'http://localhost:3000';
  
  // Decodificar contraseña en base64
  String _decodeBase64(String encoded) {
    try {
      String normalizedBase64 = encoded;
      while (normalizedBase64.length % 4 != 0) {
        normalizedBase64 += '=';
      }
      
      return utf8.decode(base64.decode(normalizedBase64));
    } catch (e) {
      if (kDebugMode) {
        print('Error decodificando base64: $e');
      }
      return encoded;
    }
  }
  
  Future<Map<String, dynamic>> login(String username, String password) async {
    try {
      // Validaciones de seguridad
      if (username.trim().isEmpty || password.trim().isEmpty) {
        throw Exception('Usuario y contraseña son requeridos');
      }
      
      if (username.length < 3) {
        throw Exception('Usuario debe tener al menos 3 caracteres');
      }
      
      if (password.length < 4) {
        throw Exception('Contraseña debe tener al menos 4 caracteres');
      }
      
      final response = await http.get(
        Uri.parse('$baseUrl/api/usuarios'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final List<dynamic> usersJson = json.decode(response.body);
        final List<User> users = usersJson.map((json) => User.fromJson(json)).toList();
        
        // Buscar usuario por nombre de usuario
        User? foundUser;
        try {
          foundUser = users.firstWhere(
            (user) => user.username.toLowerCase().trim() == username.toLowerCase().trim(),
          );
        } catch (e) {
          throw Exception('Usuario o contraseña incorrectos');
        }
        
        // Verificar si el usuario está activo
        if (!foundUser.isActivo) {
          throw Exception('Usuario inactivo. Contacte al administrador');
        }
        
        // Decodificar contraseña almacenada y comparar
        final decodedPassword = _decodeBase64(foundUser.password);
        
        if (decodedPassword.trim() != password.trim()) {
          throw Exception('Usuario o contraseña incorrectos');
        }
        
        // Obtener empresas del usuario
        final empresas = await _getEmpresas(foundUser.empresaIdList);
        
        return {
          'user': foundUser,
          'empresas': empresas,
          'token': _generateToken(foundUser),
        };
      } else if (response.statusCode == 404) {
        throw Exception('Servicio no disponible');
      } else if (response.statusCode >= 500) {
        throw Exception('Error del servidor. Intente más tarde');
      } else {
        throw Exception('Error de conexión');
      }
    } catch (e) {
      if (e.toString().contains('TimeoutException')) {
        throw Exception('Tiempo de espera agotado. Verifique su conexión');
      }
      
      if (kDebugMode) {
        print('Error en login: $e');
      }
      
      rethrow;
    }
  }
  
  Future<List<Empresa>> _getEmpresas(List<int> empresaIds) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/erpempresas'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final List<dynamic> empresasJson = json.decode(response.body);
        
        final List<Empresa> allEmpresas = [];
        for (var json in empresasJson) {
          try {
            if (json['EmpresaId'] != null) {
              allEmpresas.add(Empresa.fromJson(json));
            }
          } catch (e) {
            if (kDebugMode) {
              print('Error al procesar empresa: $e');
            }
          }
        }
        
        if (allEmpresas.isEmpty) {
          for (var id in empresaIds) {
            allEmpresas.add(Empresa(
              empresaId: id,
              nombre: 'Empresa $id',
            ));
          }
        }
        
        final filteredEmpresas = allEmpresas.where((empresa) => 
          empresaIds.contains(empresa.empresaId)
        ).toList();
        
        if (filteredEmpresas.isEmpty && allEmpresas.isNotEmpty) {
          return allEmpresas;
        }
        
        return filteredEmpresas;
      } else {
        // Crear empresas manualmente si hay error
        final List<Empresa> manualEmpresas = [];
        for (var id in empresaIds) {
          manualEmpresas.add(Empresa(
            empresaId: id,
            nombre: 'Empresa $id',
          ));
        }
        return manualEmpresas;
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error en _getEmpresas: $e');
      }
      
      // Crear empresas manualmente si hay excepción
      final List<Empresa> manualEmpresas = [];
      for (var id in empresaIds) {
        manualEmpresas.add(Empresa(
          empresaId: id,
          nombre: 'Empresa $id',
        ));
      }
      return manualEmpresas;
    }
  }
  
  String _generateToken(User user) {
    final payload = {
      'sub': user.usuarioId,
      'username': user.username,
      'empresaIds': user.empresaIds,
      'iat': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'exp': DateTime.now().add(const Duration(hours: 24)).millisecondsSinceEpoch ~/ 1000,
    };
    
    return base64.encode(utf8.encode(json.encode(payload)));
  }
}
