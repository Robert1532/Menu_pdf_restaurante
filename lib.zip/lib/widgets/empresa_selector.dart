import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../models/empresa.dart';

class EmpresaSelector extends StatefulWidget {
  const EmpresaSelector({Key? key}) : super(key: key);

  @override
  State<EmpresaSelector> createState() => _EmpresaSelectorState();
}

class _EmpresaSelectorState extends State<EmpresaSelector> {
  bool _isSelecting = false;
  int? _selectedEmpresaId;

  @override
  void initState() {
    super.initState();
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    _selectedEmpresaId = authProvider.selectedEmpresaId;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, authProvider, child) {
        final empresas = authProvider.empresas;
        
        return Scaffold(
          appBar: AppBar(
            title: const Text('Seleccionar Empresa'),
            automaticallyImplyLeading: false,
          ),
          body: _isSelecting
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 16),
                      Text('Configurando empresa...'),
                    ],
                  ),
                )
              : empresas.isEmpty
                  ? const Center(
                      child: Text('No hay empresas disponibles'),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: empresas.length,
                      itemBuilder: (ctx, index) {
                        final empresa = empresas[index];
                        final isSelected = _selectedEmpresaId == empresa.empresaId;
                        
                        return Card(
                          margin: const EdgeInsets.only(bottom: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                            side: BorderSide(
                              color: isSelected
                                  ? Theme.of(context).colorScheme.primary
                                  : Colors.transparent,
                              width: 2,
                            ),
                          ),
                          child: InkWell(
                            onTap: _isSelecting ? null : () async {
                              if (_selectedEmpresaId == empresa.empresaId) {
                                // Si ya está seleccionada, navegar de vuelta
                                Navigator.of(context).pop();
                                return;
                              }
                              
                              setState(() {
                                _isSelecting = true;
                                _selectedEmpresaId = empresa.empresaId;
                              });
                              
                              try {
                                // Seleccionar la empresa
                                authProvider.selectEmpresa(empresa.empresaId);
                                
                                // Esperar un momento para que se actualice el estado
                                await Future.delayed(const Duration(milliseconds: 300));
                                
                                if (mounted) {
                                  // Navegar de vuelta a la pantalla principal
                                  Navigator.of(context).pop();
                                }
                              } catch (e) {
                                if (mounted) {
                                  setState(() {
                                    _isSelecting = false;
                                    _selectedEmpresaId = authProvider.selectedEmpresaId;
                                  });
                                  
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text('Error al seleccionar empresa: $e'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                }
                              }
                            },
                            borderRadius: BorderRadius.circular(12),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  Container(
                                    width: 60,
                                    height: 60,
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: empresa.logo != null
                                        ? Image.network(
                                            empresa.logo!,
                                            errorBuilder: (_, __, ___) => Icon(
                                              Icons.business,
                                              size: 30,
                                              color: Theme.of(context).colorScheme.primary,
                                            ),
                                          )
                                        : Icon(
                                            Icons.business,
                                            size: 30,
                                            color: Theme.of(context).colorScheme.primary,
                                          ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          empresa.nombre,
                                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          isSelected ? 'Empresa activa' : 'Toca para seleccionar',
                                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                            color: isSelected 
                                                ? Theme.of(context).colorScheme.primary
                                                : Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (isSelected)
                                    Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: Theme.of(context).colorScheme.primary,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        Icons.check,
                                        color: Theme.of(context).colorScheme.onPrimary,
                                        size: 16,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
        );
      },
    );
  }
}
