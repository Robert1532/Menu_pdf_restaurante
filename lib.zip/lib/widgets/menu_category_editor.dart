import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/menu.dart';
import '../models/product.dart';
import '../providers/menu_provider.dart';

class MenuCategoryEditor extends StatefulWidget {
  final MenuCategory category;
  final Function(String) onDescriptionChanged;
  final Function(int) onProductToggled;
  
  const MenuCategoryEditor({
    Key? key,
    required this.category,
    required this.onDescriptionChanged,
    required this.onProductToggled,
  }) : super(key: key);

  @override
  State<MenuCategoryEditor> createState() => _MenuCategoryEditorState();
}

class _MenuCategoryEditorState extends State<MenuCategoryEditor> {
  final _descriptionController = TextEditingController();
  bool _isExpanded = false;
  
  @override
  void initState() {
    super.initState();
    _descriptionController.text = widget.category.description ?? '';
  }
  
  @override
  void dispose() {
    _descriptionController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Consumer<MenuProvider>(
      builder: (context, menuProvider, child) {
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Column(
            children: [
              // Encabezado
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.category,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                title: Text(
                  widget.category.name,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text('${widget.category.products.length} productos'),
                trailing: IconButton(
                  icon: Icon(_isExpanded ? Icons.expand_less : Icons.expand_more),
                  onPressed: () {
                    setState(() {
                      _isExpanded = !_isExpanded;
                    });
                  },
                ),
              ),
              
              // Contenido expandible
              if (_isExpanded) ...[
                const Divider(),
                
                // Descripción
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextField(
                    controller: _descriptionController,
                    decoration: const InputDecoration(
                      labelText: 'Descripción de la categoría',
                      border: OutlineInputBorder(),
                      helperText: 'Descripción opcional que aparecerá en el PDF',
                    ),
                    maxLines: 2,
                    onChanged: widget.onDescriptionChanged,
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // Lista de productos
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Icon(
                        Icons.restaurant_menu,
                        size: 20,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'Productos',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Selecciona los productos para incluir en el menú',
                          style: TextStyle(
                            fontSize: 12, 
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 8),
                
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: widget.category.products.length,
                  itemBuilder: (ctx, index) {
                    final product = widget.category.products[index];
                    return CheckboxListTile(
                      title: Text(product.nombre),
                      subtitle: Text(
                        '${product.precio.toStringAsFixed(2)} Bs.',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                      value: product.isSelected,
                      onChanged: (value) {
                        widget.onProductToggled(product.productoId);
                      },
                      secondary: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: product.isDisponible 
                              ? Colors.green.withOpacity(0.1)
                              : Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Icon(
                          product.isDisponible ? Icons.check_circle : Icons.cancel,
                          color: product.isDisponible ? Colors.green : Colors.red,
                          size: 16,
                        ),
                      ),
                    );
                  },
                ),
                
                const SizedBox(height: 8),
              ],
            ],
          ),
        );
      },
    );
  }
}


