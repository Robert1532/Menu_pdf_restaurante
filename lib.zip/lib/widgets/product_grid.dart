import 'package:flutter/material.dart';

import '../models/product.dart';

enum GridType {
  mobile,
  tablet,
  desktop,
}

class ProductGrid extends StatelessWidget {
  final List<Product> products;
  final Function(BuildContext, Product) onProductSelected;
  final GridType gridType;
  
  const ProductGrid({
    Key? key,
    required this.products,
    required this.onProductSelected,
    this.gridType = GridType.mobile,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (products.isEmpty) {
      return const Center(
        child: Text('No hay productos en esta categoría'),
      );
    }
    
    // Configuración adaptativa según el tipo de dispositivo
    int crossAxisCount;
    double childAspectRatio;
    double padding;
    
    switch (gridType) {
      case GridType.mobile:
        crossAxisCount = 2;
        childAspectRatio = 0.85;
        padding = 8.0;
        break;
      case GridType.tablet:
        crossAxisCount = 3;
        childAspectRatio = 0.9;
        padding = 12.0;
        break;
      case GridType.desktop:
        crossAxisCount = 4;
        childAspectRatio = 1.0;
        padding = 16.0;
        break;
    }
    
    return GridView.builder(
      padding: EdgeInsets.all(padding),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        childAspectRatio: childAspectRatio,
        crossAxisSpacing: padding,
        mainAxisSpacing: padding,
      ),
      itemCount: products.length,
      itemBuilder: (ctx, index) {
        final product = products[index];
        
        return ProductCard(
          product: product,
          onTap: () => onProductSelected(context, product),
        );
      },
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onTap;
  
  const ProductCard({
    Key? key,
    required this.product,
    required this.onTap,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Imagen o placeholder con badge de precio
            Stack(
              children: [
                Container(
                  height: 100,
                  width: double.infinity,
                  color: Colors.grey.shade100,
                  child: Center(
                    child: Icon(
                      Icons.restaurant,
                      size: 40,
                      color: Theme.of(context).colorScheme.primary.withOpacity(0.7),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(8),
                      ),
                    ),
                    child: Text(
                      '${product.precio.toStringAsFixed(2)} Bs.',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
                if (product.isFavorito)
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: Colors.amber,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.star,
                        color: Colors.white,
                        size: 12,
                      ),
                    ),
                  ),
              ],
            ),
            
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Nombre del producto
                    Text(
                      product.nombre,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    
                    const SizedBox(height: 4),
                    
                    // Descripción corta
                    Expanded(
                      child: Text(
                        product.descripcion,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    
                    // Indicador de disponibilidad
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: product.isDisponible 
                            ? Colors.green.withOpacity(0.1)
                            : Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        product.isDisponible ? 'Disponible' : 'No disponible',
                        style: TextStyle(
                          fontSize: 10,
                          color: product.isDisponible ? Colors.green.shade800 : Colors.red.shade800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
