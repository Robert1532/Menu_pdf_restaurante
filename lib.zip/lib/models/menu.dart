import 'product.dart';
import 'promotion.dart';

class Menu {
  String title;
  String? description;
  DateTime createdAt;
  List<MenuCategory> categories;
  List<Promotion> promotions;
  
  Menu({
    required this.title,
    this.description,
    required this.createdAt,
    required this.categories,
    required this.promotions,
  });
  
  factory Menu.empty() {
    return Menu(
      title: 'Nuevo Menú',
      createdAt: DateTime.now(),
      description: '',
      categories: [],
      promotions: [],
    );
  }
}

class MenuCategory {
  String name;
  String? description;
  List<Product> products;
  
  MenuCategory({
    required this.name,
    this.description,
    required this.products,
  });
}
